<h1 align="center">Front-end para comércio eletrônico</h1>
Atividade prática supervisionada do primeiro semestre de Ciência da Computação: "Front-end Comércio Eletrônico".

<h4>Integrantes:</h4>
<ul>
  <li>Malu Martins</li>
  <li>Erick Donizeti S Rodrigues</li>
  <li>Nivaldo Ribeiro de Sousa Filho</li>
  <li>Cauan de Souza Gimenes</li>
  <li>Cauã Frazão</li>
</ul>
